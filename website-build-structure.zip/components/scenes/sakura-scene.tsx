'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import { useFrame, useThree } from '@react-three/fiber'
import { OrbitControls, useCursor } from '@react-three/drei'
import * as THREE from 'three'
import { useExperience } from '@/lib/experience-store'
import { soundFactory } from '@/lib/audio'
import { makeBarkTexture } from '@/lib/textures'

function mulberry32(seed: number) {
  return () => {
    let t = (seed += 0x6d2b79f5)
    t = Math.imul(t ^ (t >>> 15), t | 1)
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61)
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

type Branch = {
  start: THREE.Vector3
  end: THREE.Vector3
  radius: number
}

function buildTree(seed = 7) {
  const rand = mulberry32(seed)
  const branches: Branch[] = []
  const blossoms: THREE.Vector3[] = []

  const add = (
    start: THREE.Vector3,
    dir: THREE.Vector3,
    length: number,
    radius: number,
    depth: number,
  ) => {
    const end = start.clone().add(dir.clone().normalize().multiplyScalar(length))
    branches.push({ start: start.clone(), end, radius })
    if (depth === 0) {
      const count = 5 + Math.floor(rand() * 5)
      for (let i = 0; i < count; i++) {
        blossoms.push(
          end.clone().add(
            new THREE.Vector3(
              (rand() - 0.5) * 0.55,
              (rand() - 0.2) * 0.4,
              (rand() - 0.5) * 0.55,
            ),
          ),
        )
      }
      return
    }
    const splits = depth > 2 ? 4 : 3
    for (let i = 0; i < splits; i++) {
      const yaw = (i / splits) * Math.PI * 2 + rand() * 0.5
      const pitch = -0.28 - rand() * 0.55
      const next = dir
        .clone()
        .applyAxisAngle(new THREE.Vector3(0, 1, 0), yaw)
        .applyAxisAngle(new THREE.Vector3(1, 0, 0), pitch)
        .normalize()
      add(end, next, length * (0.58 + rand() * 0.14), radius * 0.6, depth - 1)
    }
  }

  add(new THREE.Vector3(0, 0, 0), new THREE.Vector3(0, 1, 0), 1.9, 0.22, 3)
  return { branches, blossoms }
}

function Tree({ onSelect }: { onSelect: () => void }) {
  const { branches, blossoms } = useMemo(() => buildTree(), [])
  const bark = useMemo(() => makeBarkTexture(), [])
  const [hovered, setHovered] = useState(false)
  useCursor(hovered)
  const blossomMesh = useRef<THREE.InstancedMesh>(null)
  const dummy = useMemo(() => new THREE.Object3D(), [])

  useEffect(() => {
    const mesh = blossomMesh.current
    if (!mesh) return
    blossoms.forEach((pos, i) => {
      dummy.position.copy(pos)
      dummy.scale.setScalar(0.08 + (i % 5) * 0.018)
      dummy.rotation.set(0, i, 0)
      dummy.updateMatrix()
      mesh.setMatrixAt(i, dummy.matrix)
    })
    mesh.instanceMatrix.needsUpdate = true
  }, [blossoms, dummy])

  return (
    <group
      onClick={(event) => {
        event.stopPropagation()
        onSelect()
        soundFactory.play('sakura-rustle')
      }}
      onPointerOver={() => setHovered(true)}
      onPointerOut={() => setHovered(false)}
    >
      {branches.map((branch, i) => {
        const dir = branch.end.clone().sub(branch.start)
        const length = dir.length()
        const mid = branch.start.clone().add(dir.clone().multiplyScalar(0.5))
        const quat = new THREE.Quaternion().setFromUnitVectors(
          new THREE.Vector3(0, 1, 0),
          dir.clone().normalize(),
        )
        return (
          <mesh key={i} position={mid} quaternion={quat}>
            <cylinderGeometry args={[branch.radius * 0.62, branch.radius, length, 7]} />
            <meshStandardMaterial map={bark} roughness={0.9} color="#6b4a38" />
          </mesh>
        )
      })}
      <instancedMesh ref={blossomMesh} args={[undefined, undefined, blossoms.length]}>
        <sphereGeometry args={[1, 8, 8]} />
        <meshStandardMaterial color="#f3c1d4" roughness={0.55} emissive="#7a3048" emissiveIntensity={0.12} />
      </instancedMesh>
    </group>
  )
}

function Petals({ count }: { count: number }) {
  const mesh = useRef<THREE.InstancedMesh>(null)
  const dummy = useMemo(() => new THREE.Object3D(), [])
  const data = useMemo(() => {
    return Array.from({ length: count }, () => ({
      x: (Math.random() - 0.5) * 16,
      y: Math.random() * 9 + 1.5,
      z: (Math.random() - 0.5) * 16,
      vx: (Math.random() - 0.5) * 0.25,
      vy: -0.18 - Math.random() * 0.28,
      vz: (Math.random() - 0.5) * 0.25,
      rx: Math.random() * Math.PI,
      ry: Math.random() * Math.PI,
      rz: Math.random() * Math.PI,
      rvx: (Math.random() - 0.5) * 1.4,
      rvy: (Math.random() - 0.5) * 1.4,
      rvz: (Math.random() - 0.5) * 1.4,
      scale: 0.07 + Math.random() * 0.08,
    }))
  }, [count])

  useFrame((state, delta) => {
    const inst = mesh.current
    if (!inst) return
    const t = state.clock.elapsedTime
    const wind = Math.sin(t * 0.35) * 0.35
    data.forEach((petal, i) => {
      petal.vx += (wind - petal.vx) * 0.02
      petal.x += petal.vx * delta * 2.2
      petal.y += petal.vy * delta * 2.2
      petal.z += (petal.vz + Math.sin(t + i) * 0.05) * delta * 2.2
      petal.rx += petal.rvx * delta
      petal.ry += petal.rvy * delta
      petal.rz += petal.rvz * delta
      if (petal.y < 0.05) {
        petal.y = 7 + Math.random() * 3
        petal.x = (Math.random() - 0.5) * 16
        petal.z = (Math.random() - 0.5) * 16
      }
      dummy.position.set(petal.x, petal.y, petal.z)
      dummy.rotation.set(petal.rx, petal.ry, petal.rz)
      dummy.scale.set(petal.scale, petal.scale * 0.35, petal.scale * 1.2)
      dummy.updateMatrix()
      inst.setMatrixAt(i, dummy.matrix)
    })
    inst.instanceMatrix.needsUpdate = true
  })

  return (
    <instancedMesh ref={mesh} args={[undefined, undefined, count]}>
      <planeGeometry args={[1, 1]} />
      <meshStandardMaterial
        color="#f4c2d7"
        side={THREE.DoubleSide}
        roughness={0.6}
        transparent
        opacity={0.92}
        depthWrite={false}
      />
    </instancedMesh>
  )
}

function Grass({ count }: { count: number }) {
  const mesh = useRef<THREE.InstancedMesh>(null)
  const dummy = useMemo(() => new THREE.Object3D(), [])

  useEffect(() => {
    const inst = mesh.current
    if (!inst) return
    for (let i = 0; i < count; i++) {
      const r = Math.sqrt(Math.random()) * 7.5
      const a = Math.random() * Math.PI * 2
      dummy.position.set(Math.cos(a) * r, 0.18, Math.sin(a) * r)
      dummy.scale.set(0.04, 0.25 + Math.random() * 0.35, 0.02)
      dummy.rotation.set(0, a, (Math.random() - 0.5) * 0.2)
      dummy.updateMatrix()
      inst.setMatrixAt(i, dummy.matrix)
    }
    inst.instanceMatrix.needsUpdate = true
  }, [count, dummy])

  useFrame((state) => {
    if (mesh.current) {
      mesh.current.rotation.y = Math.sin(state.clock.elapsedTime * 0.25) * 0.02
    }
  })

  return (
    <instancedMesh ref={mesh} args={[undefined, undefined, count]}>
      <boxGeometry args={[1, 1, 1]} />
      <meshStandardMaterial color="#4f7a3a" roughness={0.85} />
    </instancedMesh>
  )
}

export function SakuraScene() {
  const { scene } = useThree()
  const { focused, setFocused, config, reducedMotion } = useExperience()
  const look = useRef(new THREE.Vector3(0, 2.1, 0))
  const [orbitReady, setOrbitReady] = useState(false)

  useEffect(() => {
    const previousBackground = scene.background
    const previousFog = scene.fog
    scene.background = new THREE.Color('#1b1420')
    scene.fog = new THREE.Fog('#c7b3b8', 14, 38)
    return () => {
      scene.background = previousBackground
      scene.fog = previousFog
    }
  }, [scene])

  useEffect(() => {
    if (!focused) {
      setOrbitReady(false)
      return
    }
    const id = window.setTimeout(() => setOrbitReady(true), reducedMotion ? 80 : 700)
    return () => window.clearTimeout(id)
  }, [focused, reducedMotion])

  useFrame((state, delta) => {
    if (orbitReady) return
    const goal = focused ? new THREE.Vector3(4.2, 2.6, 4.2) : new THREE.Vector3(0.4, 2.4, 8.4)
    const k = 1 - Math.pow(reducedMotion ? 0.0001 : 0.02, delta)
    state.camera.position.lerp(goal, k)
    look.current.lerp(new THREE.Vector3(0, 2.15, 0), k)
    state.camera.lookAt(look.current)
  })

  return (
    <>
      <mesh>
        <sphereGeometry args={[48, 32, 24]} />
        <shaderMaterial
          side={THREE.BackSide}
          vertexShader={`varying vec3 vPos; void main(){ vPos = position; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`}
          fragmentShader={`
            varying vec3 vPos;
            void main() {
              float h = normalize(vPos).y;
              vec3 bot = vec3(0.42, 0.28, 0.32);
              vec3 mid = vec3(0.86, 0.68, 0.72);
              vec3 top = vec3(0.22, 0.2, 0.32);
              vec3 col = mix(bot, mid, smoothstep(-0.15, 0.18, h));
              col = mix(col, top, smoothstep(0.18, 0.72, h));
              gl_FragColor = vec4(col, 1.0);
            }
          `}
        />
      </mesh>
      <ambientLight intensity={0.45} color="#ffd9e8" />
      <directionalLight position={[6, 8, 4]} intensity={1.55} color="#ffe7d2" />
      <hemisphereLight args={['#f7d6e6', '#3d4a30', 0.4]} />

      <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <circleGeometry args={[12, 64]} />
        <meshStandardMaterial color="#3f5c32" roughness={0.95} />
      </mesh>
      <Grass count={config.grass} />
      <Petals count={config.petals} />
      <Tree onSelect={() => (focused ? soundFactory.play('petal') : setFocused(true))} />

      <OrbitControls
        enabled={orbitReady}
        enablePan={false}
        enableDamping
        dampingFactor={0.08}
        minDistance={3.2}
        maxDistance={11}
        minPolarAngle={0.35}
        maxPolarAngle={1.35}
        target={[0, 2.1, 0]}
      />
    </>
  )
}
