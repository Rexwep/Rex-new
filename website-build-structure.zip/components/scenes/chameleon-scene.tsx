'use client'

import { useEffect, useMemo, useRef } from 'react'
import { useFrame, useThree } from '@react-three/fiber'
import * as THREE from 'three'
import { useExperience } from '@/lib/experience-store'
import { soundFactory } from '@/lib/audio'
import { DustField } from '@/components/scenes/dust'

const COLORS = [
  new THREE.Color('#3f8a4a'),
  new THREE.Color('#9db83a'),
  new THREE.Color('#c49a4a'),
  new THREE.Color('#5d7c45'),
]

function Eye({ position }: { position: [number, number, number] }) {
  const ref = useRef<THREE.Group>(null)
  const { camera } = useThree()

  useFrame(() => {
    ref.current?.lookAt(camera.position)
  })

  return (
    <group ref={ref} position={position}>
      <mesh>
        <sphereGeometry args={[0.085, 16, 16]} />
        <meshStandardMaterial color="#efe6d4" roughness={0.35} />
      </mesh>
      <mesh position={[0, 0, 0.05]}>
        <sphereGeometry args={[0.042, 12, 12]} />
        <meshStandardMaterial color="#16140f" roughness={0.2} />
      </mesh>
    </group>
  )
}

function Leg({
  offset,
  side,
  fore,
  material,
}: {
  offset: number
  side: number
  fore: number
  material: THREE.MeshStandardMaterial
}) {
  const ref = useRef<THREE.Group>(null)

  useFrame((state) => {
    if (!ref.current) return
    const t = state.clock.elapsedTime * 3.1 + offset
    const swing = Math.sin(t) * 0.55
    const lift = Math.max(0, Math.sin(t)) * 0.12
    ref.current.rotation.z = swing * 0.35 * side
    ref.current.rotation.x = swing * 0.45 + (fore < 0 ? 0.15 : -0.05)
    ref.current.position.y = lift
  })

  return (
    <group ref={ref} position={[fore * 0.34, -0.12, side * 0.2]}>
      <mesh position={[0, -0.16, 0]} rotation={[0, 0, side * 0.25]} material={material}>
        <capsuleGeometry args={[0.045, 0.22, 4, 8]} />
      </mesh>
      <mesh position={[side * 0.02, -0.34, 0.02]} material={material}>
        <sphereGeometry args={[0.055, 10, 10]} />
      </mesh>
    </group>
  )
}

function Chameleon() {
  const group = useRef<THREE.Group>(null)
  const head = useRef<THREE.Group>(null)
  const tail = useRef<THREE.Mesh>(null)
  const { camera } = useThree()
  const { reducedMotion } = useExperience()
  const material = useMemo(
    () =>
      new THREE.MeshStandardMaterial({
        color: COLORS[0],
        roughness: 0.46,
        metalness: 0.08,
      }),
    [],
  )
  const target = useMemo(() => new THREE.Color().copy(COLORS[0]), [])
  const lookQuat = useMemo(() => new THREE.Quaternion(), [])
  const restQuat = useMemo(() => new THREE.Quaternion(), [])
  const lastColor = useRef(0)
  const lastLookSound = useRef(0)

  const tailGeom = useMemo(() => {
    const curve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(0, 0, 0),
      new THREE.Vector3(-0.35, 0.08, 0.05),
      new THREE.Vector3(-0.7, 0.22, -0.04),
      new THREE.Vector3(-0.85, 0.02, 0.12),
      new THREE.Vector3(-0.7, -0.18, 0.18),
      new THREE.Vector3(-0.42, -0.08, 0.08),
    ])
    return new THREE.TubeGeometry(curve, 40, 0.055, 8, false)
  }, [])

  useFrame((state) => {
    const t = state.clock.elapsedTime
    const cycle = t % 22
    let walk = 1
    let look = 0
    let heading = Math.sin(t * 0.15) * 0.35

    if (cycle < 4) {
      walk = 1
    } else if (cycle < 7) {
      walk = 0.7
      const i = Math.floor((t * 0.25) % COLORS.length)
      if (i !== lastColor.current) {
        lastColor.current = i
        target.copy(COLORS[i])
        soundFactory.play('chameleon')
      }
    } else if (cycle < 11) {
      walk = 1
    } else if (cycle < 13) {
      walk = 0.25
    } else if (cycle < 16) {
      walk = 0
      look = 1
      heading = 0
      if (t - lastLookSound.current > 8) {
        lastLookSound.current = t
        soundFactory.play('chameleon')
      }
    } else if (cycle < 17.5) {
      walk = 0.15
      look = Math.max(0, 1 - (cycle - 16) / 1.5)
    } else {
      walk = 1
    }

    material.color.lerp(target, 0.03)

    if (!group.current) return
    const x = Math.sin(t * 0.22) * 1.45
    const dir = Math.cos(t * 0.22)
    group.current.position.x = x
    group.current.position.y = 0.52 + Math.sin(t * 3.1 * Math.max(walk, 0.15)) * 0.04 * walk
    group.current.position.z = 0.02
    group.current.rotation.y = (dir >= 0 ? 0 : Math.PI) + heading * (1 - look)

    if (head.current) {
      if (look > 0.01) {
        const p = camera.position.clone()
        head.current.parent?.worldToLocal(p)
        const m = new THREE.Matrix4().lookAt(new THREE.Vector3(), p, new THREE.Vector3(0, 1, 0))
        lookQuat.setFromRotationMatrix(m)
        head.current.quaternion.slerp(lookQuat, 0.08 * look)
      } else {
        head.current.quaternion.slerp(restQuat, 0.06)
      }
    }

    if (tail.current && !reducedMotion) {
      tail.current.rotation.y = Math.sin(t * 2.2) * 0.18
    }
  })

  return (
    <group
      ref={group}
      scale={1.15}
      onClick={(event) => {
        event.stopPropagation()
        soundFactory.play('chameleon')
      }}
    >
      <mesh material={material} position={[0.1, 0.08, 0]} rotation={[0, 0, -0.18]} scale={[1.35, 0.78, 0.72]} castShadow>
        <sphereGeometry args={[0.32, 24, 18]} />
      </mesh>
      <mesh material={material} position={[-0.28, 0.04, 0]} scale={[1.35, 0.62, 0.7]} castShadow>
        <sphereGeometry args={[0.28, 20, 16]} />
      </mesh>
      <group ref={head} position={[0.38, 0.16, 0]}>
        <mesh material={material} scale={[1.05, 0.78, 0.72]}>
          <sphereGeometry args={[0.22, 20, 16]} />
        </mesh>
        <mesh material={material} position={[-0.02, 0.16, 0]} rotation={[0, 0, -0.4]} scale={[0.55, 0.7, 0.22]}>
          <sphereGeometry args={[0.18, 12, 12]} />
        </mesh>
        <Eye position={[0.12, 0.08, 0.14]} />
        <Eye position={[0.12, 0.08, -0.14]} />
        <mesh position={[0.2, -0.02, 0]} rotation={[0, 0, Math.PI / 2]}>
          <coneGeometry args={[0.04, 0.12, 8]} />
          <meshStandardMaterial color="#1d1a14" />
        </mesh>
      </group>
      <mesh ref={tail} geometry={tailGeom} material={material} position={[-0.42, 0.02, 0]} />
      <Leg offset={0} side={1} fore={1} material={material} />
      <Leg offset={Math.PI} side={-1} fore={1} material={material} />
      <Leg offset={Math.PI} side={1} fore={-1} material={material} />
      <Leg offset={0} side={-1} fore={-1} material={material} />
    </group>
  )
}

function Fern({ position, rotation = 0 }: { position: [number, number, number]; rotation?: number }) {
  return (
    <group position={position} rotation={[0, rotation, 0]}>
      {Array.from({ length: 7 }).map((_, i) => (
        <mesh key={i} position={[0, 0.2, 0]} rotation={[0.4, (i / 7) * Math.PI * 2, 0.15]}>
          <coneGeometry args={[0.12, 0.7, 5]} />
          <meshStandardMaterial color={i % 2 ? '#2f5a32' : '#3f7340'} roughness={0.85} />
        </mesh>
      ))}
    </group>
  )
}

export function ChameleonScene() {
  const { scene } = useThree()
  const { config, reducedMotion } = useExperience()
  const look = useRef(new THREE.Vector3(0, 0.45, 0))

  useEffect(() => {
    const previousBackground = scene.background
    const previousFog = scene.fog
    scene.background = new THREE.Color('#0c140d')
    scene.fog = new THREE.Fog('#0c140d', 7, 22)
    return () => {
      scene.background = previousBackground
      scene.fog = previousFog
    }
  }, [scene])

  useFrame((state, delta) => {
    const t = state.clock.elapsedTime
    const goal = new THREE.Vector3(Math.sin(t * 0.1) * 0.35 + 0.15, 1.7, 5.8)
    const k = 1 - Math.pow(reducedMotion ? 0.0001 : 0.02, delta)
    state.camera.position.lerp(goal, k)
    look.current.lerp(new THREE.Vector3(0, 0.55, 0), k)
    state.camera.lookAt(look.current)
  })

  return (
    <>
      <ambientLight intensity={0.28} color="#c9e0b8" />
      <directionalLight
        position={[4, 7, 3]}
        intensity={1.6}
        color="#fff2d0"
        castShadow={config.shadows}
        shadow-mapSize={[1024, 1024]}
      />
      <spotLight position={[-3, 5, 2]} intensity={0.6} color="#8fce6a" angle={0.6} penumbra={0.8} />
      <DustField count={Math.floor(config.dust * 0.7)} color="#d7ecc4" spread={9} speed={0.12} />

      <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <circleGeometry args={[9, 48]} />
        <meshStandardMaterial color="#1b2a18" roughness={0.95} />
      </mesh>
      <mesh position={[0, 0.2, 0]} rotation={[0, 0, Math.PI / 2]} receiveShadow>
        <cylinderGeometry args={[0.2, 0.23, 3.4, 18]} />
        <meshStandardMaterial color="#4a3424" roughness={0.9} />
      </mesh>
      <Fern position={[-1.8, 0, -1.1]} rotation={0.4} />
      <Fern position={[2.1, 0, -0.6]} rotation={1.2} />
      <Fern position={[0.8, 0, -1.8]} rotation={2.1} />
      <mesh position={[-2.4, 0.18, 0.8]}>
        <icosahedronGeometry args={[0.28, 0]} />
        <meshStandardMaterial color="#3a4034" roughness={0.8} />
      </mesh>
      <Chameleon />
    </>
  )
}
