'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import { useFrame, useThree } from '@react-three/fiber'
import { Float, useCursor } from '@react-three/drei'
import * as THREE from 'three'
import { useExperience } from '@/lib/experience-store'
import { soundFactory } from '@/lib/audio'
import { DustField } from '@/components/scenes/dust'

function makeWaterMaterial() {
  return new THREE.ShaderMaterial({
    uniforms: {
      uTime: { value: 0 },
      uRippleA: { value: new THREE.Vector4(0, 0, 10, 0) },
      uRippleB: { value: new THREE.Vector4(0, 0, 10, 0) },
      uRippleC: { value: new THREE.Vector4(0, 0, 10, 0) },
      uDepth: { value: new THREE.Color('#073445') },
      uSurface: { value: new THREE.Color('#8fd4e8') },
      uFog: { value: new THREE.Color('#08222c') },
    },
    transparent: true,
    vertexShader: `
      uniform float uTime;
      uniform vec4 uRippleA;
      uniform vec4 uRippleB;
      uniform vec4 uRippleC;
      varying vec3 vWorld;
      varying vec3 vN;
      varying float vElev;

      float wave(vec2 p) {
        float e = sin(p.x * 0.85 + uTime * 0.85) * 0.22;
        e += sin(p.y * 0.72 + uTime * 0.64) * 0.18;
        e += sin((p.x + p.y) * 1.45 + uTime * 1.15) * 0.08;
        e += sin(p.x * 2.4 - p.y * 1.6 + uTime * 1.6) * 0.03;
        return e;
      }

      float ripple(vec4 r, vec2 p) {
        if (r.w <= 0.001) return 0.0;
        float d = length(p - r.xy);
        return sin(d * 13.0 - r.z * 5.2) * exp(-d * 1.25) * exp(-r.z * 0.55) * r.w;
      }

      void main() {
        vec3 p = position;
        float e = wave(p.xz);
        e += ripple(uRippleA, p.xz);
        e += ripple(uRippleB, p.xz);
        e += ripple(uRippleC, p.xz);
        p.y += e;
        vElev = e;
        vec3 dx = vec3(0.12, wave(p.xz + vec2(0.12, 0.0)) - e, 0.0);
        vec3 dz = vec3(0.0, wave(p.xz + vec2(0.0, 0.12)) - e, 0.12);
        vN = normalize(cross(dz, dx));
        vec4 world = modelMatrix * vec4(p, 1.0);
        vWorld = world.xyz;
        gl_Position = projectionMatrix * viewMatrix * world;
      }
    `,
    fragmentShader: `
      uniform vec3 uDepth;
      uniform vec3 uSurface;
      uniform vec3 uFog;
      varying vec3 vWorld;
      varying vec3 vN;
      varying float vElev;
      void main() {
        vec3 n = normalize(vN);
        vec3 view = normalize(cameraPosition - vWorld);
        float fresnel = pow(1.0 - max(dot(n, view), 0.0), 3.0);
        vec3 color = mix(uDepth, uSurface, vElev * 2.5 + 0.35);
        color += fresnel * vec3(0.65, 0.85, 1.0) * 0.45;
        float fog = smoothstep(6.0, 22.0, length(cameraPosition - vWorld));
        color = mix(color, uFog, fog);
        gl_FragColor = vec4(color, 0.92);
      }
    `,
  })
}

export function WaterScene() {
  const { scene, camera } = useThree()
  const { focused, setFocused, config, reducedMotion } = useExperience()
  const material = useMemo(() => makeWaterMaterial(), [])
  const progress = useRef(0)
  const look = useRef(new THREE.Vector3(0, 0.35, 0))
  const ripples = useRef([
    new THREE.Vector4(0, 0, 12, 0),
    new THREE.Vector4(0, 0, 12, 0),
    new THREE.Vector4(0, 0, 12, 0),
  ])
  const rippleIndex = useRef(0)
  const [hovered, setHovered] = useState(false)
  useCursor(hovered)

  useEffect(() => {
    const previousBackground = scene.background
    const previousFog = scene.fog
    scene.background = new THREE.Color('#08222c')
    scene.fog = new THREE.Fog('#08222c', 8, 26)
    return () => {
      scene.background = previousBackground
      scene.fog = previousFog
      material.dispose()
    }
  }, [scene, material])

  useEffect(() => {
    const onWheel = (event: WheelEvent) => {
      progress.current = THREE.MathUtils.clamp(progress.current + event.deltaY * 0.00055, 0, 1)
    }
    let lastY: number | null = null
    const onTouchMove = (event: TouchEvent) => {
      const y = event.touches[0]?.clientY
      if (y == null) return
      if (lastY != null) {
        progress.current = THREE.MathUtils.clamp(progress.current + (lastY - y) * 0.0035, 0, 1)
      }
      lastY = y
    }
    const onTouchEnd = () => {
      lastY = null
    }
    window.addEventListener('wheel', onWheel, { passive: true })
    window.addEventListener('touchmove', onTouchMove, { passive: true })
    window.addEventListener('touchend', onTouchEnd)
    return () => {
      window.removeEventListener('wheel', onWheel)
      window.removeEventListener('touchmove', onTouchMove)
      window.removeEventListener('touchend', onTouchEnd)
    }
  }, [])

  useFrame((state, delta) => {
    material.uniforms.uTime.value = state.clock.elapsedTime
    ripples.current.forEach((ripple) => {
      ripple.z += delta
    })
    material.uniforms.uRippleA.value.copy(ripples.current[0])
    material.uniforms.uRippleB.value.copy(ripples.current[1])
    material.uniforms.uRippleC.value.copy(ripples.current[2])

    const p = progress.current
    const far = new THREE.Vector3(0, 1.85, 6.2)
    const mid = new THREE.Vector3(0.4, 1.05, 3.4)
    const close = new THREE.Vector3(0.15, 0.72, 2.15)
    const goal = focused
      ? close
      : far.clone().lerp(mid, p)
    const k = 1 - Math.pow(reducedMotion ? 0.0001 : 0.02, delta)
    camera.position.lerp(goal, k)
    look.current.lerp(new THREE.Vector3(0, focused ? 0.55 : 0.25 + p * 0.2, 0), k)
    camera.lookAt(look.current)
  })

  const addRipple = (x: number, z: number) => {
    const slot = ripples.current[rippleIndex.current % 3]
    slot.set(x, z, 0, 0.42)
    rippleIndex.current += 1
    soundFactory.play('water-ripple')
  }

  return (
    <>
      <ambientLight intensity={0.32} color="#9fd4e4" />
      <directionalLight position={[4, 8, 3]} intensity={1.5} color="#e9fbff" />
      <pointLight position={[0, 1.4, 0]} intensity={1.1} color="#7fe0ff" />
      <DustField count={config.dust} color="#d7f4ff" spread={14} speed={0.05} />

      <mesh
        rotation={[-Math.PI / 2, 0, 0]}
        onClick={(event) => {
          event.stopPropagation()
          addRipple(event.point.x, event.point.z)
        }}
      >
        <planeGeometry args={[28, 28, config.earthSeg > 40 ? 96 : 48, config.earthSeg > 40 ? 96 : 48]} />
        <primitive object={material} attach="material" />
      </mesh>

      <Float speed={1.4} floatIntensity={0.35} rotationIntensity={0.15}>
        <mesh
          position={[0, 0.7, 0]}
          onPointerOver={() => setHovered(true)}
          onPointerOut={() => setHovered(false)}
          onClick={(event) => {
            event.stopPropagation()
            addRipple(event.point.x, event.point.z)
            soundFactory.play('water-drop')
            if (!focused) setFocused(true)
          }}
        >
          <icosahedronGeometry args={[0.46, 3]} />
          <meshStandardMaterial
            color="#8fd8ea"
            roughness={0.12}
            metalness={0.35}
            emissive="#245e6e"
            emissiveIntensity={0.35}
          />
        </mesh>
      </Float>

      <mesh position={[0, 0.02, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <ringGeometry args={[1.1, 1.28, 48]} />
        <meshBasicMaterial color="#b9ecff" transparent opacity={0.18} />
      </mesh>
    </>
  )
}
