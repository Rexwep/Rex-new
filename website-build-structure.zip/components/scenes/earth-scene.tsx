'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import { useFrame, useThree } from '@react-three/fiber'
import { OrbitControls, Stars, useCursor } from '@react-three/drei'
import * as THREE from 'three'
import { useExperience } from '@/lib/experience-store'
import { soundFactory } from '@/lib/audio'
import { DustField } from '@/components/scenes/dust'

const FAR = new THREE.Vector3(0, 0.35, 4.35)
const NEAR = new THREE.Vector3(0.15, 0.12, 2.15)

const NOISE_GLSL = `
float hash(vec2 p) {
  return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
}
float noise(vec2 p) {
  vec2 i = floor(p);
  vec2 f = fract(p);
  f = f * f * (3.0 - 2.0 * f);
  return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), f.x), mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), f.x), f.y);
}
float fbm(vec2 p) {
  float v = 0.0;
  float a = 0.5;
  for (int i = 0; i < 5; i++) {
    v += a * noise(p);
    p *= 2.03;
    a *= 0.5;
  }
  return v;
}
`

function Atmosphere() {
  const material = useMemo(
    () =>
      new THREE.ShaderMaterial({
        uniforms: {
          uColor: { value: new THREE.Color('#7eb6ff') },
        },
        vertexShader: `
          varying vec3 vNormal;
          varying vec3 vView;
          void main() {
            vec4 world = modelMatrix * vec4(position, 1.0);
            vNormal = normalize(mat3(modelMatrix) * normal);
            vView = normalize(cameraPosition - world.xyz);
            gl_Position = projectionMatrix * viewMatrix * world;
          }
        `,
        fragmentShader: `
          varying vec3 vNormal;
          varying vec3 vView;
          uniform vec3 uColor;
          void main() {
            float fresnel = pow(1.0 - abs(dot(normalize(vNormal), normalize(vView))), 3.6);
            gl_FragColor = vec4(uColor, clamp(fresnel * 0.85, 0.0, 0.7));
          }
        `,
        side: THREE.BackSide,
        transparent: true,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        toneMapped: false,
      }),
    [],
  )

  return (
    <mesh scale={1.028}>
      <sphereGeometry args={[1, 64, 64]} />
      <primitive object={material} attach="material" />
    </mesh>
  )
}

function EarthGlobe() {
  const { focused, setFocused, config, reducedMotion } = useExperience()
  const group = useRef<THREE.Group>(null)
  const clouds = useRef<THREE.Mesh>(null)
  const earthMat = useRef<THREE.ShaderMaterial>(null)
  const dragging = useRef(false)
  const [hovered, setHovered] = useState(false)
  useCursor(hovered && !focused)

  const material = useMemo(
    () =>
      new THREE.ShaderMaterial({
        uniforms: {
          uLight: { value: new THREE.Vector3(0.7, 0.35, 0.45).normalize() },
          uTime: { value: 0 },
        },
        vertexShader: `
          varying vec3 vN;
          varying vec3 vPos;
          varying vec2 vUv;
          void main() {
            vUv = uv;
            vN = normalize(mat3(modelMatrix) * normal);
            vPos = position;
            gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
          }
        `,
        fragmentShader: `
          ${NOISE_GLSL}
          uniform vec3 uLight;
          varying vec3 vN;
          varying vec3 vPos;
          varying vec2 vUv;
          void main() {
            vec3 n = normalize(vN);
            float lat = vUv.y;
            vec2 p = vec2(vUv.x * 6.4, vUv.y * 3.2);
            float landN = fbm(p);
            float extra = fbm(p * 2.4 + 12.0);
            float land = smoothstep(0.48, 0.55, landN - abs(lat - 0.5) * 0.08);
            vec3 ocean = vec3(0.03, 0.12, 0.32);
            vec3 oceanDeep = vec3(0.01, 0.05, 0.16);
            vec3 grass = vec3(0.18, 0.38, 0.16);
            vec3 forest = vec3(0.08, 0.24, 0.1);
            vec3 desert = vec3(0.55, 0.42, 0.22);
            vec3 ice = vec3(0.86, 0.91, 0.95);
            vec3 ground = mix(grass, forest, extra);
            ground = mix(ground, desert, smoothstep(0.42, 0.58, lat) * extra);
            float iceCap = smoothstep(0.18, 0.08, lat) + smoothstep(0.82, 0.92, lat);
            vec3 albedo = mix(mix(oceanDeep, ocean, extra), ground, land);
            albedo = mix(albedo, ice, clamp(iceCap, 0.0, 1.0));
            float ndl = dot(n, normalize(uLight));
            float wrap = ndl * 0.65 + 0.35;
            float spec = pow(max(ndl, 0.0), 48.0) * (1.0 - land) * 0.45;
            vec3 night = albedo * vec3(0.07, 0.09, 0.16);
            float cities = smoothstep(0.62, 0.8, extra) * land * (1.0 - iceCap);
            night += vec3(1.0, 0.82, 0.45) * cities * 0.35 * (1.0 - smoothstep(-0.05, 0.25, ndl));
            vec3 col = mix(night, albedo * wrap, smoothstep(-0.2, 0.22, ndl));
            col += spec * vec3(0.75, 0.88, 1.0);
            gl_FragColor = vec4(col, 1.0);
          }
        `,
      }),
    [],
  )

  const cloudMat = useMemo(
    () =>
      new THREE.ShaderMaterial({
        transparent: true,
        depthWrite: false,
        uniforms: { uTime: { value: 0 } },
        vertexShader: `
          varying vec2 vUv;
          void main() {
            vUv = uv;
            gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
          }
        `,
        fragmentShader: `
          ${NOISE_GLSL}
          varying vec2 vUv;
          void main() {
            float c = fbm(vec2(vUv.x * 8.0, vUv.y * 4.0));
            float alpha = smoothstep(0.52, 0.78, c) * 0.55;
            gl_FragColor = vec4(vec3(0.93, 0.95, 0.98), alpha);
          }
        `,
      }),
    [],
  )

  useEffect(() => {
    earthMat.current = material
    return () => {
      material.dispose()
      cloudMat.dispose()
    }
  }, [material, cloudMat])

  useFrame((_, delta) => {
    if (!group.current) return
    if (!dragging.current && !reducedMotion) {
      group.current.rotation.y += delta * (focused ? 0.04 : 0.08)
    }
    if (clouds.current && !reducedMotion) {
      clouds.current.rotation.y += delta * 0.03
    }
  })

  return (
    <group ref={group}>
      <mesh
        onPointerOver={() => setHovered(true)}
        onPointerOut={() => setHovered(false)}
        onPointerDown={() => {
          dragging.current = true
        }}
        onPointerUp={() => {
          dragging.current = false
        }}
        onClick={(event) => {
          event.stopPropagation()
          if (!focused) setFocused(true)
          else soundFactory.play('earth-rotate')
        }}
      >
        <sphereGeometry args={[1, config.earthSeg, config.earthSeg]} />
        <primitive object={material} attach="material" />
      </mesh>
      <mesh ref={clouds} scale={1.016}>
        <sphereGeometry args={[1, Math.max(24, config.earthSeg - 16), Math.max(24, config.earthSeg - 16)]} />
        <primitive object={cloudMat} attach="material" />
      </mesh>
      <Atmosphere />
    </group>
  )
}

function EarthCamera() {
  const { focused, reducedMotion } = useExperience()
  const look = useRef(new THREE.Vector3())
  const [orbitReady, setOrbitReady] = useState(false)

  useEffect(() => {
    if (!focused) {
      setOrbitReady(false)
      return
    }
    const id = window.setTimeout(() => setOrbitReady(true), reducedMotion ? 80 : 680)
    return () => window.clearTimeout(id)
  }, [focused, reducedMotion])

  useFrame((state, delta) => {
    if (orbitReady) return
    const target = focused ? NEAR : FAR
    const k = 1 - Math.pow(reducedMotion ? 0.0001 : 0.018, delta)
    state.camera.position.lerp(target, k)
    look.current.lerp(new THREE.Vector3(0, 0, 0), k)
    state.camera.lookAt(look.current)
  })

  return (
    <OrbitControls
      enabled={orbitReady}
      enablePan={false}
      enableDamping
      dampingFactor={0.08}
      minDistance={1.55}
      maxDistance={4.8}
      rotateSpeed={0.7}
      zoomSpeed={0.7}
      onStart={() => soundFactory.play('earth-rotate')}
    />
  )
}

export function EarthScene() {
  const { config } = useExperience()
  const { scene } = useThree()

  useEffect(() => {
    const previousBackground = scene.background
    const previousFog = scene.fog
    scene.background = new THREE.Color('#05060b')
    scene.fog = new THREE.Fog('#05060b', 10, 36)
    return () => {
      scene.background = previousBackground
      scene.fog = previousFog
    }
  }, [scene])

  return (
    <>
      <EarthCamera />
      <ambientLight intensity={0.22} color="#8aa4c8" />
      <directionalLight position={[5.2, 2.2, 3.4]} intensity={0.9} color="#fff1dc" />
      <Stars
        radius={90}
        depth={40}
        count={config.stars}
        factor={3.4}
        fade
        speed={0.35}
      />
      <DustField count={config.dust} color="#b9d4ff" spread={12} />
      <group position={[0, -0.05, 0]}>
        <EarthGlobe />
      </group>
    </>
  )
}
