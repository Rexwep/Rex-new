'use client'

import { useMemo, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'

function makeCircleTexture() {
  const el = document.createElement('canvas')
  el.width = 64
  el.height = 64
  const ctx = el.getContext('2d')
  if (!ctx) return null
  const gradient = ctx.createRadialGradient(32, 32, 0, 32, 32, 32)
  gradient.addColorStop(0, 'rgba(255,255,255,1)')
  gradient.addColorStop(0.45, 'rgba(255,255,255,0.45)')
  gradient.addColorStop(1, 'rgba(255,255,255,0)')
  ctx.fillStyle = gradient
  ctx.fillRect(0, 0, 64, 64)
  const texture = new THREE.CanvasTexture(el)
  texture.needsUpdate = true
  return texture
}

export function DustField({
  count = 160,
  color = '#c9d6e8',
  spread = 10,
  speed = 0.08,
}: {
  count?: number
  color?: string
  spread?: number
  speed?: number
}) {
  const ref = useRef<THREE.Points>(null)
  const map = useMemo(() => makeCircleTexture(), [])
  const positions = useMemo(() => {
    const arr = new Float32Array(count * 3)
    for (let i = 0; i < count; i++) {
      const radius = spread * 0.35 + Math.random() * spread * 0.55
      const theta = Math.random() * Math.PI * 2
      const phi = Math.acos(2 * Math.random() - 1)
      arr[i * 3] = radius * Math.sin(phi) * Math.cos(theta)
      arr[i * 3 + 1] = radius * Math.cos(phi) * 0.7
      arr[i * 3 + 2] = radius * Math.sin(phi) * Math.sin(theta)
    }
    return arr
  }, [count, spread])

  useFrame((state) => {
    const points = ref.current
    if (!points) return
    points.rotation.y = state.clock.elapsedTime * speed * 0.15
  })

  return (
    <points ref={ref}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
      </bufferGeometry>
      <pointsMaterial
        color={color}
        map={map ?? undefined}
        size={0.07}
        transparent
        opacity={0.5}
        depthWrite={false}
        sizeAttenuation
        alphaTest={0.04}
      />
    </points>
  )
}
