'use client'

import { ArrowLeft, ArrowRight } from 'lucide-react'
import { WORLD_META, WORLD_ORDER, useExperience } from '@/lib/experience-store'
import { ProjectCta } from '@/components/experience/project-cta'
import { cn } from '@/lib/utils'

export function WorldHud() {
  const { world, focused, setFocused, visitWorld, transitioning } = useExperience()
  const meta = WORLD_META[world]
  const next = meta.next

  return (
    <>
      <div
        className={cn(
          'pointer-events-none absolute inset-x-0 top-0 z-20 flex items-start justify-between p-5 sm:p-8',
          transitioning && 'opacity-70',
        )}
      >
        <div className="pointer-events-none">
          <p className="cinematic-kicker">Four Worlds</p>
          <p className="mt-2 text-sm text-foreground/70">Cinematic atelier</p>
        </div>
      </div>

      {focused ? (
        <button
          type="button"
          onClick={() => setFocused(false)}
          className="pointer-events-auto glass-capsule absolute top-6 left-1/2 z-30 flex -translate-x-1/2 items-center gap-2 rounded-full px-4 py-2 text-[0.68rem] tracking-[0.22em] uppercase"
        >
          <ArrowLeft className="size-3.5" />
          Back
        </button>
      ) : null}

      <div className="pointer-events-none absolute inset-x-0 bottom-0 z-20 flex flex-col gap-6 p-5 sm:p-8">
        <div
          className={cn(
            'flex flex-col gap-6 transition-opacity duration-500 sm:flex-row sm:items-end sm:justify-between',
            focused && 'pointer-events-none opacity-0',
          )}
        >
          <div className="max-w-xl">
            <p className="cinematic-kicker">
              {meta.index} / 04 — {meta.kicker}
            </p>
            <h1 className="cinematic-title mt-3 text-4xl text-foreground sm:text-6xl">
              {meta.title}
            </h1>
            <p className="mt-4 max-w-md text-sm leading-relaxed text-foreground/68 sm:text-base">
              {meta.line}
            </p>
            <p className="mt-3 text-xs tracking-[0.18em] text-foreground/40 uppercase">
              {meta.hint}
            </p>
          </div>

          <div className="pointer-events-auto flex flex-col items-start gap-3 sm:items-end">
            {world === 'sakura' ? (
              <div className="flex flex-col items-start gap-3 sm:items-end">
                <p className="cinematic-kicker">Ready to create?</p>
                <ProjectCta />
              </div>
            ) : (
              <>
                <ProjectCta className="opacity-90" />
                {next ? (
                  <button
                    type="button"
                    onClick={() => visitWorld(next)}
                    className="flex items-center gap-2 text-[0.68rem] tracking-[0.22em] text-foreground/70 uppercase transition-colors hover:text-foreground"
                  >
                    Continue to {WORLD_META[next].title}
                    <ArrowRight className="size-3.5" />
                  </button>
                ) : null}
              </>
            )}
          </div>
        </div>

        <ol className="pointer-events-auto flex gap-2" aria-label="World progress">
          {WORLD_ORDER.map((id) => (
            <li key={id}>
              <button
                type="button"
                aria-label={WORLD_META[id].title}
                aria-current={id === world ? 'page' : undefined}
                onClick={() => visitWorld(id)}
                className={cn(
                  'block h-1 rounded-full transition-all duration-500',
                  id === world ? 'w-10 bg-foreground' : 'w-4 bg-foreground/25 hover:bg-foreground/50',
                )}
              />
            </li>
          ))}
        </ol>
      </div>
    </>
  )
}
