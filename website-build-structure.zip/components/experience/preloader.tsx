'use client'

import { useEffect, useState } from 'react'
import { useExperience } from '@/lib/experience-store'
import { ProjectCta } from '@/components/experience/project-cta'

export function Preloader() {
  const { start, reducedMotion } = useExperience()
  const [phase, setPhase] = useState<'black' | 'signature' | 'ready'>('black')

  useEffect(() => {
    const first = window.setTimeout(() => setPhase('signature'), reducedMotion ? 80 : 700)
    const second = window.setTimeout(() => setPhase('ready'), reducedMotion ? 160 : 2100)
    return () => {
      window.clearTimeout(first)
      window.clearTimeout(second)
    }
  }, [reducedMotion])

  return (
    <div className="absolute inset-0 z-40 grid place-items-center bg-[#07080c]">
      <div className="flex max-w-lg flex-col items-center px-6 text-center">
        <div
          className="mb-10 h-px w-40 origin-center bg-foreground/70"
          style={{
            animation: phase === 'black' ? 'none' : 'signature-line 1.1s cubic-bezier(0.22,1,0.36,1) both',
            opacity: phase === 'black' ? 0 : 1,
          }}
        />
        <p
          className="cinematic-kicker"
          style={{ opacity: phase === 'black' ? 0 : 1, transition: 'opacity 700ms ease' }}
        >
          Signature intro
        </p>
        <h1
          className="cinematic-title mt-5 text-5xl sm:text-7xl"
          style={{
            opacity: phase === 'black' ? 0 : 1,
            transform: phase === 'black' ? 'translateY(12px)' : 'translateY(0)',
            transition: 'opacity 900ms ease, transform 900ms cubic-bezier(0.22,1,0.36,1)',
          }}
        >
          Four Worlds
        </h1>
        <p
          className="mt-5 max-w-sm text-sm leading-relaxed text-foreground/60"
          style={{ opacity: phase === 'ready' ? 1 : 0, transition: 'opacity 700ms ease' }}
        >
          Earth. Living colour. Water. Sakura. A single cinematic system of image, sound, and touch.
        </p>

        <div
          className="mt-10 flex flex-col items-center gap-4"
          style={{ opacity: phase === 'ready' ? 1 : 0, transition: 'opacity 700ms ease 80ms' }}
        >
          <button
            type="button"
            onClick={() => void start()}
            className="project-cta"
          >
            <span className="size-2 rounded-full bg-foreground" />
            Enter the origin
          </button>
          <p className="text-[0.65rem] tracking-[0.2em] text-foreground/35 uppercase">
            Sound opens with the experience
          </p>
          <ProjectCta className="scale-90 opacity-80" />
        </div>
      </div>
    </div>
  )
}
