'use client'

import { Canvas } from '@react-three/fiber'
import { AdaptiveDpr } from '@react-three/drei'
import * as THREE from 'three'
import { useExperience } from '@/lib/experience-store'
import { EarthScene } from '@/components/scenes/earth-scene'
import { ChameleonScene } from '@/components/scenes/chameleon-scene'
import { WaterScene } from '@/components/scenes/water-scene'
import { SakuraScene } from '@/components/scenes/sakura-scene'

export function ExperienceCanvas() {
  const { world, config, started } = useExperience()

  if (!started) return null

  return (
    <div className="absolute inset-0 touch-none">
      <Canvas
        dpr={config.dpr}
        shadows={config.shadows}
        gl={{
          antialias: true,
          toneMapping: THREE.ACESFilmicToneMapping,
          toneMappingExposure: 0.92,
          powerPreference: 'high-performance',
        }}
        camera={{ fov: 38, near: 0.1, far: 220, position: [0, 0.4, 4.4] }}
        onCreated={({ gl }) => {
          gl.setClearColor('#07080c', 1)
        }}
      >
        <AdaptiveDpr pixelated={false} />
        {world === 'origin' ? <EarthScene key="origin" /> : null}
        {world === 'living' ? <ChameleonScene key="living" /> : null}
        {world === 'element' ? <WaterScene key="element" /> : null}
        {world === 'sakura' ? <SakuraScene key="sakura" /> : null}
      </Canvas>
    </div>
  )
}
