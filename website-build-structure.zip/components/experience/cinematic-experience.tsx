'use client'

import { useEffect } from 'react'
import dynamic from 'next/dynamic'
import { ExperienceProvider, WORLD_ORDER, useExperience } from '@/lib/experience-store'
import { FloatingMenu } from '@/components/experience/floating-menu'
import { Preloader } from '@/components/experience/preloader'
import { WorldHud } from '@/components/experience/world-hud'

const ExperienceCanvas = dynamic(
  () =>
    import('@/components/experience/experience-canvas').then((mod) => mod.ExperienceCanvas),
  { ssr: false },
)

function Shell() {
  const { started, world, focused, setFocused, visitWorld, toggleMute, transitioning } =
    useExperience()

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape' && focused) setFocused(false)
      if (event.key === 'm' || event.key === 'M') toggleMute()
      const num = Number(event.key)
      if (num >= 1 && num <= 4) visitWorld(WORLD_ORDER[num - 1])
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [focused, setFocused, toggleMute, visitWorld])

  return (
    <div
      data-world={world}
      className="relative h-dvh w-full overflow-hidden bg-[#07080c] text-foreground"
    >
      <a
        href="#world-stage"
        className="sr-only focus:not-sr-only focus:absolute focus:top-3 focus:left-3 focus:z-50 focus:rounded-full focus:bg-foreground focus:px-4 focus:py-2 focus:text-background"
      >
        Skip to world
      </a>
      <ExperienceCanvas />
      <div className="vignette absolute inset-0 z-10" />
      <div className="film-grain absolute inset-0 z-10" />
      <div
        className="pointer-events-none absolute inset-0 z-10 bg-[color-mix(in_oklch,var(--world-accent)_12%,transparent)] mix-blend-soft-light transition-opacity duration-700"
        style={{ opacity: transitioning ? 0.55 : 0.18 }}
      />

      {started ? (
        <div id="world-stage" className="contents">
          <div className="pointer-events-none absolute top-5 right-5 z-30 sm:top-8 sm:right-8">
            <FloatingMenu />
          </div>
          <WorldHud />
        </div>
      ) : (
        <Preloader />
      )}
    </div>
  )
}

export function CinematicExperience() {
  return (
    <ExperienceProvider>
      <Shell />
    </ExperienceProvider>
  )
}
