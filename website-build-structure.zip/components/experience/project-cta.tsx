'use client'

import { useExperience } from '@/lib/experience-store'
import { WhatsAppMark } from '@/components/experience/whatsapp-mark'
import { cn } from '@/lib/utils'

export function ProjectCta({
  className,
  label = 'Start your project',
}: {
  className?: string
  label?: string
}) {
  const { startProject } = useExperience()

  return (
    <button
      type="button"
      className={cn('project-cta', className)}
      onClick={startProject}
      aria-label={`${label}. Opens WhatsApp to discuss a website project.`}
    >
      <span className="wa-indicator">
        <WhatsAppMark className="size-3.5" />
      </span>
      {label}
    </button>
  )
}
