'use client'

import { useEffect, useId, useState } from 'react'
import { Volume2, VolumeX } from 'lucide-react'
import { soundFactory } from '@/lib/audio'
import { useExperience, type WorldId } from '@/lib/experience-store'
import { cn } from '@/lib/utils'

const ITEMS: Array<{ id: string; label: string; world?: WorldId; project?: boolean }> = [
  { id: 'home', label: 'Home', world: 'origin' },
  { id: 'origin', label: 'Origin', world: 'origin' },
  { id: 'living', label: 'Living World', world: 'living' },
  { id: 'element', label: 'Element', world: 'element' },
  { id: 'sakura', label: 'Sakura', world: 'sakura' },
  { id: 'project', label: 'Start a project', project: true },
]

export function FloatingMenu() {
  const { world, visitWorld, startProject, muted, toggleMute } = useExperience()
  const [open, setOpen] = useState(false)
  const menuId = useId()

  useEffect(() => {
    if (!open) return
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setOpen(false)
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [open])

  const toggle = () => {
    soundFactory.play(open ? 'menu-close' : 'menu-open')
    setOpen((value) => !value)
  }

  return (
    <div className="pointer-events-auto flex items-start gap-2">
      <button
        type="button"
        onClick={toggleMute}
        className="glass-capsule grid size-11 place-items-center rounded-full text-foreground/80 transition-transform duration-150 hover:scale-105"
        aria-label={muted ? 'Unmute sound' : 'Mute sound'}
      >
        {muted ? <VolumeX className="size-4" /> : <Volume2 className="size-4" />}
      </button>

      <div className="menu-shell glass-capsule min-w-44">
        <button
          type="button"
          className="flex w-full items-center justify-between px-5 py-3 text-[0.68rem] font-medium tracking-[0.28em] uppercase"
          aria-expanded={open}
          aria-controls={menuId}
          onClick={toggle}
        >
          Menu
          <span aria-hidden="true" className="text-foreground/35">
            {open ? '–' : '+'}
          </span>
        </button>

        <div
          id={menuId}
          className={cn(
            'grid transition-[grid-template-rows] duration-500 ease-[cubic-bezier(0.22,1,0.36,1)]',
            open ? 'grid-rows-[1fr]' : 'grid-rows-[0fr]',
          )}
        >
          <nav className="overflow-hidden" aria-label="Worlds" aria-hidden={!open}>
            <ul className="flex flex-col gap-0.5 px-2 pb-3">
              {ITEMS.map((item, index) => {
                const active = item.world === world && !item.project
                const delay = open ? index * 45 : (ITEMS.length - index) * 40
                return (
                  <li
                    key={item.id}
                    style={{
                      transitionDelay: `${delay}ms`,
                      opacity: open ? 1 : 0,
                      transform: open ? 'translateY(0)' : 'translateY(-8px)',
                      transitionProperty: 'opacity, transform',
                      transitionDuration: '420ms',
                      transitionTimingFunction: 'cubic-bezier(0.22, 1, 0.36, 1)',
                    }}
                  >
                    <button
                      type="button"
                      className={cn(
                        'flex w-full rounded-full px-4 py-2.5 text-left text-[0.72rem] tracking-[0.16em] uppercase transition-colors',
                        active
                          ? 'bg-foreground/10 text-foreground'
                          : 'text-foreground/70 hover:bg-foreground/6 hover:text-foreground',
                      )}
                      onClick={() => {
                        if (item.project) {
                          startProject()
                        } else if (item.world) {
                          visitWorld(item.world)
                        }
                        soundFactory.play('menu-close')
                        setOpen(false)
                      }}
                    >
                      {item.label}
                    </button>
                  </li>
                )
              })}
            </ul>
          </nav>
        </div>
      </div>
    </div>
  )
}
