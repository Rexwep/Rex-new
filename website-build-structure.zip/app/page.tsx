import { CinematicExperience } from '@/components/experience/cinematic-experience'

export default function Page() {
  return (
    <main className="h-dvh overflow-hidden">
      <CinematicExperience />
    </main>
  )
}
