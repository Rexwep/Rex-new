export type SoundName =
  | 'menu-open'
  | 'menu-close'
  | 'button'
  | 'navigation'
  | 'back'
  | 'earth-select'
  | 'earth-rotate'
  | 'chameleon'
  | 'leaf'
  | 'water-drop'
  | 'water-ripple'
  | 'sakura-rustle'
  | 'petal'
  | 'project'

export type WorldAmbience = 'origin' | 'living' | 'element' | 'sakura' | 'none'

type NoiseKind = 'white' | 'pink' | 'brown'

class SoundFactory {
  private ctx: AudioContext | null = null
  private master: GainNode | null = null
  private ui: GainNode | null = null
  private environment: GainNode | null = null
  private ambience: GainNode | null = null
  private muted = false
  private unlocked = false
  private lastPlayed = new Map<string, number>()
  private noiseCache = new Map<NoiseKind, AudioBuffer>()
  private ambienceCleanup: (() => void) | null = null
  private currentWorld: WorldAmbience = 'none'

  get isUnlocked() {
    return this.unlocked
  }

  get isMuted() {
    return this.muted
  }

  async unlock() {
    this.ensure()
    if (!this.ctx) return
    if (this.ctx.state === 'suspended') {
      await this.ctx.resume()
    }
    this.unlocked = true
  }

  setMuted(next: boolean) {
    this.muted = next
    if (this.master && this.ctx) {
      this.master.gain.setTargetAtTime(next ? 0 : 0.72, this.ctx.currentTime, 0.05)
    }
  }

  play(name: SoundName) {
    if (!this.unlocked || this.muted) return
    this.ensure()
    const ctx = this.ctx
    const ui = this.ui
    const env = this.environment
    if (!ctx || !ui || !env) return

    const cooldown = name === 'earth-rotate' || name === 'petal' ? 280 : 70
    const last = this.lastPlayed.get(name) ?? 0
    if (ctx.currentTime - last < cooldown / 1000) return
    this.lastPlayed.set(name, ctx.currentTime)

    switch (name) {
      case 'menu-open':
        this.tactile(ui, 210, 0.045)
        this.tone(ui, 420, 0.09, 0.03, 'triangle')
        break
      case 'menu-close':
        this.tactile(ui, 170, 0.04)
        this.tone(ui, 280, 0.08, 0.025, 'sine')
        break
      case 'button':
      case 'navigation':
        this.tactile(ui, 190, 0.032)
        break
      case 'back':
        this.tactile(ui, 150, 0.04)
        this.tone(ui, 240, 0.1, 0.02, 'sine')
        break
      case 'earth-select':
        this.whoosh(env, 0.28)
        this.tone(env, 92, 0.4, 0.05, 'sine')
        break
      case 'earth-rotate':
        this.whoosh(env, 0.12, 0.018)
        break
      case 'chameleon':
        this.organic(env)
        break
      case 'leaf':
        this.noiseBurst(env, 'pink', 0.12, 900, 0.03)
        break
      case 'water-drop':
        this.drop(env)
        break
      case 'water-ripple':
        this.noiseBurst(env, 'brown', 0.22, 600, 0.04)
        this.tone(env, 180, 0.25, 0.03, 'sine')
        break
      case 'sakura-rustle':
        this.noiseBurst(env, 'pink', 0.16, 1400, 0.028)
        break
      case 'petal':
        this.tone(env, 880 + Math.random() * 220, 0.08, 0.012, 'sine')
        break
      case 'project':
        this.tactile(ui, 200, 0.04)
        this.tone(ui, 510, 0.11, 0.035, 'sine')
        this.tone(ui, 760, 0.09, 0.018, 'triangle')
        break
    }
  }

  setWorld(world: WorldAmbience) {
    if (this.currentWorld === world) return
    this.currentWorld = world
    this.stopAmbience()
    if (!this.unlocked || world === 'none') return
    this.startAmbience(world)
  }

  destroy() {
    this.stopAmbience()
    void this.ctx?.close()
    this.ctx = null
  }

  private ensure() {
    if (this.ctx) return
    if (typeof window === 'undefined') return
    const ctx = new AudioContext()
    const master = ctx.createGain()
    master.gain.value = this.muted ? 0 : 0.72
    master.connect(ctx.destination)

    const ui = ctx.createGain()
    ui.gain.value = 0.5
    ui.connect(master)

    const environment = ctx.createGain()
    environment.gain.value = 0.48
    environment.connect(master)

    const ambience = ctx.createGain()
    ambience.gain.value = 0.0
    ambience.connect(master)

    this.ctx = ctx
    this.master = master
    this.ui = ui
    this.environment = environment
    this.ambience = ambience
  }

  private vary(base: number, amount = 0.06) {
    return base * (1 - amount + Math.random() * amount * 2)
  }

  private tactile(dest: AudioNode, freq: number, gain = 0.04) {
    const ctx = this.ctx
    if (!ctx) return
    const t = ctx.currentTime
    const osc = ctx.createOscillator()
    const g = ctx.createGain()
    osc.type = 'sine'
    osc.frequency.value = this.vary(freq, 0.08)
    g.gain.setValueAtTime(gain, t)
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.045)
    osc.connect(g)
    g.connect(dest)
    osc.start(t)
    osc.stop(t + 0.05)
    this.noiseBurst(dest, 'white', 0.03, 1800, gain * 0.45)
  }

  private tone(
    dest: AudioNode,
    freq: number,
    dur: number,
    gain: number,
    type: OscillatorType,
  ) {
    const ctx = this.ctx
    if (!ctx) return
    const t = ctx.currentTime
    const osc = ctx.createOscillator()
    const g = ctx.createGain()
    osc.type = type
    osc.frequency.value = this.vary(freq, 0.05)
    g.gain.setValueAtTime(0.0001, t)
    g.gain.exponentialRampToValueAtTime(gain, t + 0.012)
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur)
    osc.connect(g)
    g.connect(dest)
    osc.start(t)
    osc.stop(t + dur + 0.02)
  }

  private whoosh(dest: AudioNode, dur = 0.2, gain = 0.04) {
    this.noiseBurst(dest, 'pink', dur, 700, gain)
  }

  private organic(dest: AudioNode) {
    this.noiseBurst(dest, 'pink', 0.18, 1100, 0.03)
    this.tone(dest, 140, 0.22, 0.02, 'triangle')
  }

  private drop(dest: AudioNode) {
    const ctx = this.ctx
    if (!ctx) return
    const t = ctx.currentTime
    const osc = ctx.createOscillator()
    const g = ctx.createGain()
    osc.type = 'sine'
    osc.frequency.setValueAtTime(this.vary(780, 0.08), t)
    osc.frequency.exponentialRampToValueAtTime(180, t + 0.18)
    g.gain.setValueAtTime(0.05, t)
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.2)
    osc.connect(g)
    g.connect(dest)
    osc.start(t)
    osc.stop(t + 0.22)
  }

  private noiseBurst(
    dest: AudioNode,
    kind: NoiseKind,
    dur: number,
    cutoff: number,
    gain: number,
  ) {
    const ctx = this.ctx
    if (!ctx) return
    const source = ctx.createBufferSource()
    source.buffer = this.getNoise(kind)
    const filter = ctx.createBiquadFilter()
    filter.type = 'bandpass'
    filter.frequency.value = this.vary(cutoff, 0.1)
    filter.Q.value = 0.7
    const g = ctx.createGain()
    const t = ctx.currentTime
    g.gain.setValueAtTime(gain, t)
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur)
    source.connect(filter)
    filter.connect(g)
    g.connect(dest)
    source.start(t)
    source.stop(t + dur + 0.02)
  }

  private getNoise(kind: NoiseKind) {
    const cached = this.noiseCache.get(kind)
    if (cached) return cached
    const ctx = this.ctx!
    const length = ctx.sampleRate * 2
    const buffer = ctx.createBuffer(1, length, ctx.sampleRate)
    const data = buffer.getChannelData(0)
    let last = 0
    let b0 = 0
    let b1 = 0
    let b2 = 0
    for (let i = 0; i < length; i++) {
      const white = Math.random() * 2 - 1
      if (kind === 'white') {
        data[i] = white * 0.5
      } else if (kind === 'brown') {
        last = (last + 0.02 * white) / 1.02
        data[i] = last * 3.5
      } else {
        b0 = 0.99765 * b0 + white * 0.099046
        b1 = 0.963 * b1 + white * 0.2965164
        b2 = 0.5703 * b2 + white * 1.052691
        data[i] = (b0 + b1 + b2 + white * 0.1848) * 0.11
      }
    }
    this.noiseCache.set(kind, buffer)
    return buffer
  }

  private startAmbience(world: WorldAmbience) {
    const ctx = this.ctx
    const bus = this.ambience
    if (!ctx || !bus) return

    const nodes: AudioNode[] = []
    const stops: Array<() => void> = []
    const t = ctx.currentTime
    bus.gain.cancelScheduledValues(t)
    bus.gain.setValueAtTime(bus.gain.value, t)
    bus.gain.linearRampToValueAtTime(0.32, t + 1.4)

    const drone = (freq: number, type: OscillatorType, gain: number) => {
      const osc = ctx.createOscillator()
      const g = ctx.createGain()
      osc.type = type
      osc.frequency.value = freq
      g.gain.value = gain
      osc.connect(g)
      g.connect(bus)
      osc.start()
      nodes.push(osc, g)
      stops.push(() => osc.stop())
    }

    const pad = (kind: NoiseKind, cutoff: number, gain: number) => {
      const src = ctx.createBufferSource()
      src.buffer = this.getNoise(kind)
      src.loop = true
      const filter = ctx.createBiquadFilter()
      filter.type = 'lowpass'
      filter.frequency.value = cutoff
      const g = ctx.createGain()
      g.gain.value = gain
      src.connect(filter)
      filter.connect(g)
      g.connect(bus)
      src.start()
      nodes.push(src, filter, g)
      stops.push(() => src.stop())
    }

    if (world === 'origin') {
      drone(48, 'sine', 0.18)
      drone(96.2, 'sine', 0.05)
      pad('pink', 420, 0.08)
    } else if (world === 'living') {
      pad('pink', 1200, 0.16)
      drone(110, 'triangle', 0.04)
    } else if (world === 'element') {
      pad('brown', 500, 0.22)
      pad('white', 1800, 0.03)
      drone(64, 'sine', 0.06)
    } else if (world === 'sakura') {
      pad('pink', 900, 0.14)
      drone(196, 'sine', 0.03)
      drone(294, 'sine', 0.015)
    }

    this.ambienceCleanup = () => {
      const now = ctx.currentTime
      bus.gain.cancelScheduledValues(now)
      bus.gain.setValueAtTime(bus.gain.value, now)
      bus.gain.linearRampToValueAtTime(0, now + 0.6)
      window.setTimeout(() => {
        stops.forEach((stop) => {
          try {
            stop()
          } catch {
            /* already stopped */
          }
        })
        nodes.length = 0
      }, 650)
    }
  }

  private stopAmbience() {
    this.ambienceCleanup?.()
    this.ambienceCleanup = null
  }
}

export const soundFactory = new SoundFactory()
