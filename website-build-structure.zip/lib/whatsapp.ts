export const WHATSAPP_NUMBER = '919257116983'
export const WHATSAPP_DISPLAY = '+91 92571 16983'

export const PROJECT_MESSAGE = `Hello, I want to discuss a website project.

I found your website and would like to discuss the project requirements, design, budget and timeline.`

export function getWhatsAppUrl() {
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(PROJECT_MESSAGE)}`
}

export function openWhatsApp() {
  const url = getWhatsAppUrl()
  window.open(url, '_blank', 'noopener,noreferrer')
}
