'use client'

import {
  createContext,
  useCallback,
  useContext,
  useMemo,
  useState,
  type ReactNode,
} from 'react'
import { soundFactory } from '@/lib/audio'
import { detectQuality, qualityConfig, type Quality } from '@/lib/performance'
import { openWhatsApp } from '@/lib/whatsapp'

export type WorldId = 'origin' | 'living' | 'element' | 'sakura'

export const WORLD_ORDER: WorldId[] = ['origin', 'living', 'element', 'sakura']

export const WORLD_META: Record<
  WorldId,
  {
    index: string
    title: string
    kicker: string
    path: string
    next: WorldId | null
    line: string
    hint: string
  }
> = {
  origin: {
    index: '01',
    title: 'The Origin',
    kicker: 'Earth',
    path: '/',
    next: 'living',
    line: 'A living planet, turning in quiet light.',
    hint: 'Click the Earth to enter orbit.',
  },
  living: {
    index: '02',
    title: 'The Living World',
    kicker: 'Chameleon',
    path: '/living-world',
    next: 'element',
    line: 'Colour is a language. Motion is a reply.',
    hint: 'Watch it walk, shift, and look back.',
  },
  element: {
    index: '03',
    title: 'The Element',
    kicker: 'Water',
    path: '/element',
    next: 'sakura',
    line: 'A surface that remembers every touch.',
    hint: 'Click the water. Scroll to move through it.',
  },
  sakura: {
    index: '04',
    title: 'Sakura World',
    kicker: 'Blossom',
    path: '/sakura',
    next: null,
    line: 'Wind, petal, and the pause before spring.',
    hint: 'Click the tree to walk around it.',
  },
}

type ExperienceContextValue = {
  started: boolean
  world: WorldId
  focused: boolean
  transitioning: boolean
  muted: boolean
  quality: Quality
  config: ReturnType<typeof qualityConfig>
  reducedMotion: boolean
  start: () => Promise<void>
  visitWorld: (world: WorldId) => void
  setFocused: (value: boolean) => void
  toggleMute: () => void
  startProject: () => void
}

const ExperienceContext = createContext<ExperienceContextValue | null>(null)

export function ExperienceProvider({ children }: { children: ReactNode }) {
  const [started, setStarted] = useState(false)
  const [world, setWorld] = useState<WorldId>('origin')
  const [focused, setFocusedState] = useState(false)
  const [transitioning, setTransitioning] = useState(false)
  const [muted, setMuted] = useState(false)
  const [quality] = useState<Quality>(() => detectQuality())
  const [reducedMotion] = useState(() =>
    typeof window !== 'undefined'
      ? window.matchMedia('(prefers-reduced-motion: reduce)').matches
      : false,
  )

  const config = useMemo(() => qualityConfig(quality), [quality])

  const start = useCallback(async () => {
    await soundFactory.unlock()
    soundFactory.setWorld('origin')
    setStarted(true)
  }, [])

  const visitWorld = useCallback(
    (next: WorldId) => {
      if (transitioning) return
      if (next === world && !focused) return
      soundFactory.play('navigation')
      setFocusedState(false)
      if (next === world) return
      setTransitioning(true)
      window.setTimeout(
        () => {
          setWorld(next)
          soundFactory.setWorld(next)
          window.setTimeout(() => setTransitioning(false), reducedMotion ? 80 : 700)
        },
        reducedMotion ? 40 : 280,
      )
    },
    [world, focused, reducedMotion, transitioning],
  )

  const setFocused = useCallback((value: boolean) => {
    setFocusedState(value)
    soundFactory.play(value ? 'earth-select' : 'back')
  }, [])

  const toggleMute = useCallback(() => {
    setMuted((prev) => {
      const next = !prev
      soundFactory.setMuted(next)
      return next
    })
  }, [])

  const startProject = useCallback(() => {
    soundFactory.play('project')
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      navigator.vibrate?.(12)
    }
    openWhatsApp()
  }, [])

  const value = useMemo(
    () => ({
      started,
      world,
      focused,
      transitioning,
      muted,
      quality,
      config,
      reducedMotion,
      start,
      visitWorld,
      setFocused,
      toggleMute,
      startProject,
    }),
    [
      started,
      world,
      focused,
      transitioning,
      muted,
      quality,
      config,
      reducedMotion,
      start,
      visitWorld,
      setFocused,
      toggleMute,
      startProject,
    ],
  )

  return (
    <ExperienceContext.Provider value={value}>{children}</ExperienceContext.Provider>
  )
}

export function useExperience() {
  const ctx = useContext(ExperienceContext)
  if (!ctx) throw new Error('useExperience must be used within ExperienceProvider')
  return ctx
}
