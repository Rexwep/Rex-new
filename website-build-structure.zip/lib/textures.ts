import * as THREE from 'three'
import { fbm } from '@/lib/noise'

function canvas(width: number, height: number) {
  const el = document.createElement('canvas')
  el.width = width
  el.height = height
  const ctx = el.getContext('2d', { willReadFrequently: true })
  if (!ctx) throw new Error('Canvas unsupported')
  return { el, ctx }
}

export function makeProceduralEarth(size = 1024) {
  const { el, ctx } = canvas(size, size / 2)
  const image = ctx.createImageData(el.width, el.height)
  const data = image.data

  for (let y = 0; y < el.height; y++) {
    for (let x = 0; x < el.width; x++) {
      const u = x / el.width
      const v = y / el.height
      const lat = v * 2 - 1
      const n = fbm(u * 6, v * 3, 5)
      const ridge = fbm(u * 12 + 20, v * 6, 3)
      const ice = Math.max(0, Math.abs(lat) - 0.72) * 4
      const land = n > 0.46 + Math.abs(lat) * 0.04
      const i = (y * el.width + x) * 4

      let r: number
      let g: number
      let b: number
      if (ice > 0.2) {
        r = 226
        g = 236
        b = 245
      } else if (land) {
        const desert = Math.abs(lat) < 0.28 && ridge > 0.5
        if (desert) {
          r = 168
          g = 142
          b = 92
        } else {
          r = 62 + ridge * 40
          g = 110 + n * 50
          b = 58
        }
      } else {
        const deep = 0.35 + n * 0.2
        r = 12 + deep * 20
        g = 48 + deep * 50
        b = 96 + deep * 80
      }

      data[i] = r
      data[i + 1] = g
      data[i + 2] = b
      data[i + 3] = 255
    }
  }

  ctx.putImageData(image, 0, 0)
  const texture = new THREE.CanvasTexture(el)
  texture.colorSpace = THREE.SRGBColorSpace
  texture.anisotropy = 8
  texture.needsUpdate = true
  return texture
}

export function makeCloudTexture(size = 1024) {
  const { el, ctx } = canvas(size, size / 2)
  const image = ctx.createImageData(el.width, el.height)
  const data = image.data

  for (let y = 0; y < el.height; y++) {
    for (let x = 0; x < el.width; x++) {
      const n = fbm(x * 0.008, y * 0.016, 4)
      const c = Math.max(0, n - 0.48) * 2.4
      const i = (y * el.width + x) * 4
      const v = Math.min(255, c * 255)
      data[i] = 245
      data[i + 1] = 248
      data[i + 2] = 255
      data[i + 3] = v * 0.85
    }
  }

  ctx.putImageData(image, 0, 0)
  const texture = new THREE.CanvasTexture(el)
  texture.colorSpace = THREE.SRGBColorSpace
  texture.needsUpdate = true
  return texture
}

export function makeBarkTexture() {
  const { el, ctx } = canvas(256, 512)
  const image = ctx.createImageData(el.width, el.height)
  const data = image.data
  for (let y = 0; y < el.height; y++) {
    for (let x = 0; x < el.width; x++) {
      const n = fbm(x * 0.08, y * 0.02, 4)
      const grain = fbm(x * 0.4, y * 0.01, 2)
      const i = (y * el.width + x) * 4
      const shade = 48 + n * 40 + grain * 18
      data[i] = shade + 18
      data[i + 1] = shade
      data[i + 2] = shade - 10
      data[i + 3] = 255
    }
  }
  ctx.putImageData(image, 0, 0)
  const texture = new THREE.CanvasTexture(el)
  texture.wrapS = texture.wrapT = THREE.RepeatWrapping
  texture.colorSpace = THREE.SRGBColorSpace
  return texture
}
