export type Quality = 'high' | 'medium' | 'low'

export function detectQuality(): Quality {
  if (typeof window === 'undefined') return 'medium'

  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches
  if (reduced) return 'low'

  const ua = navigator.userAgent
  const mobile = /Mobi|Android|iPhone|iPad/i.test(ua)
  const cores = navigator.hardwareConcurrency || 4
  const memory = (navigator as Navigator & { deviceMemory?: number }).deviceMemory ?? 8
  const dpr = Math.min(window.devicePixelRatio || 1, 2)

  if (mobile && (cores <= 6 || memory <= 4)) return 'low'
  if (mobile) return 'medium'
  if (cores <= 4 || memory <= 4 || dpr < 1.25) return 'low'
  if (cores <= 8 || memory <= 8) return 'medium'
  return 'high'
}

export function qualityConfig(quality: Quality) {
  switch (quality) {
    case 'high':
      return {
        dpr: [1, 1.75] as [number, number],
        stars: 3200,
        petals: 420,
        grass: 900,
        dust: 280,
        earthSeg: 64,
        shadows: true,
        ripples: true,
      }
    case 'medium':
      return {
        dpr: [1, 1.35] as [number, number],
        stars: 1600,
        petals: 220,
        grass: 480,
        dust: 140,
        earthSeg: 48,
        shadows: false,
        ripples: true,
      }
    default:
      return {
        dpr: 1 as number | [number, number],
        stars: 700,
        petals: 90,
        grass: 180,
        dust: 60,
        earthSeg: 32,
        shadows: false,
        ripples: false,
      }
  }
}
